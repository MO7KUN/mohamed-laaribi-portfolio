/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.js'],
  theme: {
    extend: {
      colors: { ink: '#080b12', panel: '#0e1420', electric: '#4d8dff', cyan: '#62d5ff' },
      fontFamily: { sans: ['Manrope', 'ui-sans-serif', 'system-ui'] },
      boxShadow: { glow: '0 0 60px rgba(50,128,255,.18)' }
    }
  },
  plugins: []
};
